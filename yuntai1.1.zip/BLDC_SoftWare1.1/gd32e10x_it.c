/*!
    \file    gd32e10x_it.c
    \brief   interrupt service routines
    
    \version 2018-03-26, V1.0.0, demo for GD32E103
    \version 2020-09-30, V1.1.0, demo for GD32E103
    \version 2020-12-31, V1.2.0, demo for GD32E103
    \version 2022-07-14, V1.3.0, demo for GD32E103
*/

/*
    Copyright (c) 2022, GigaDevice Semiconductor Inc.

    Redistribution and use in source and binary forms, with or without modification, 
are permitted provided that the following conditions are met:

    1. Redistributions of source code must retain the above copyright notice, this 
       list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright notice, 
       this list of conditions and the following disclaimer in the documentation 
       and/or other materials provided with the distribution.
    3. Neither the name of the copyright holder nor the names of its contributors 
       may be used to endorse or promote products derived from this software without 
       specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGE.
*/

#include "gd32e10x_it.h"

#define SAMPLES_PER_PPAIR		128
#define OFFSET_LUT_NUM		  128
#define pole_pairs		      11

extern      tTraj 					Traj;	
extern      ADC_PAR     		adc_par; 
extern      USERCONFIG 			UsrConfig;
extern 		  ENCODER_PAR 		encoder_par;

int 				p_error_arr[1409];
static int 	count_10HZ = 0,sample_count = 0,inc_led_ = 0;
float 			theta_ref = 0;

void Calibration_zero(void)////Calibration zero
{
	static int 			raw_offset;
	static uint32_t loop_count;	
	static float 		next_sample_time;
	float 					time = (float)(loop_count*DT);

	switch(encoder_par.mCalibStep)
	{
		case 0:
		{
			encoder_par.raw = ReadValue()>>1;
			raw_offset = encoder_par.raw;
			apply_voltage_timings(12,2,0,0);
			if(count_10HZ >= 20000)
			{
				encoder_par.mCalibStep = 1;
				loop_count = 0;
				theta_ref =  0;
				count_10HZ = 0;
			}else{count_10HZ ++;}		
			break;
		}
		case 1:
		{
			theta_ref+= ((CALB_SPEED * DT));
			apply_voltage_timings(12,2,0,theta_ref);
			
			if(time > next_sample_time)
				{
					int count_ref = (ENCODER_CPR) * (theta_ref/((float)(pole_pairs*M_2PI)));//�����Ƕ�
					int error;
					encoder_par.raw = ReadValue()>>1;		
					error = encoder_par.raw - count_ref;
					p_error_arr[sample_count] = error + ENCODER_CPR * (error<0);	
					sample_count ++;
					if(sample_count >= pole_pairs*SAMPLES_PER_PPAIR){
						sample_count --;
					}
					next_sample_time += M_2PI/(float)(M_2PI*SAMPLES_PER_PPAIR);
				}	
			if (time >= (CALB_SPEED*pole_pairs)/CALB_SPEED){
						next_sample_time = 0;
						loop_count = 0;
						encoder_par.mCalibStep = 2;
					}
			break;
		}	
		case 2:
		{
			theta_ref -= ((CALB_SPEED * DT));
			apply_voltage_timings(12,2,0,theta_ref);
			
					
			if(time > next_sample_time)
				{
					int count_ref = ENCODER_CPR * (theta_ref/(float)(pole_pairs*M_2PI));
					int error;
					encoder_par.raw = ReadValue()>>1;
					error = (encoder_par.raw) - count_ref;
					error = error + ENCODER_CPR * (error<0);
					p_error_arr[sample_count] = (p_error_arr[sample_count] + error)/2;
					
					sample_count --;
					if(sample_count <= 0){
						sample_count = 0;
					}
					next_sample_time += M_2PI/(float)(M_2PI*SAMPLES_PER_PPAIR);
				}	
			if (time >= (CALB_SPEED*pole_pairs)/CALB_SPEED)
				{

						next_sample_time = 0;
						loop_count = 0;
						encoder_par.mCalibStep = 3;
				}
			break;
		}	
		case 3:
		{
				int64_t ezero_mean = 0;
				for(int i = 0; i<(pole_pairs*SAMPLES_PER_PPAIR); i++)
				{
					ezero_mean += p_error_arr[i];
				}
				encoder_par.raw = ReadValue()>>1;		
				UsrConfig.encoder_offset = ezero_mean/(pole_pairs*SAMPLES_PER_PPAIR);
				raw_offset += encoder_par.raw;
				raw_offset /= 2;
				Motor_Disable();		
				
				
				encoder_par.mCalibStep = 4;
				break;
		}
		case 4://�����������˲�
		{
				int window = SAMPLES_PER_PPAIR;
				raw_offset = OFFSET_LUT_NUM * raw_offset / ENCODER_CPR;
				for(int i = 0; i<OFFSET_LUT_NUM; i++){
					int moving_avg = 0;
					for(int j = (-window)/2; j<(window)/2; j++)
					{
						int index = i*pole_pairs*SAMPLES_PER_PPAIR/OFFSET_LUT_NUM + j;
						if(index < 0)
							{
								index += (SAMPLES_PER_PPAIR*pole_pairs);
							}else if(index > (SAMPLES_PER_PPAIR*pole_pairs-1))
							{
								index -= (SAMPLES_PER_PPAIR*pole_pairs);
							}
						moving_avg += p_error_arr[index];
					}
					moving_avg = moving_avg/window;
					int lut_index = raw_offset + i;
					if(lut_index > (OFFSET_LUT_NUM-1))
						{
							lut_index -= OFFSET_LUT_NUM;
						}
					UsrConfig.offset_lut[lut_index] = moving_avg - UsrConfig.encoder_offset;
				}				
				UsrConfig.calib_flag = 2;
				Write_FLASH_config();
				encoder_par.mCalibStep = 5;
				break;
		}
		
	}
	loop_count++;
}

void TIMER2_IRQHandler(void)
{

		timer_interrupt_flag_clear(TIMER2, TIMER_INT_UP); 
		Update_Register();				
		Recive_CALC();
		Send_CALC();				

		if(UsrConfig.motor_ENABLE == 2)
		{
			gpio_bit_set(GPIOB,GPIO_PIN_3);
			if((inc_led_>=0)&&(inc_led_ <= 15000))
				{
				  gpio_bit_reset(GPIOB,GPIO_PIN_4);
					inc_led_++;
				}else if((inc_led_ > 15000)&&(inc_led_ <= 30000))
				{
					gpio_bit_set(GPIOB,GPIO_PIN_4);
					inc_led_++;
					
				}else{inc_led_ = 0;}
		}
}

void ADC0_1_IRQHandler(void)
{	
	ADC_STAT(ADC0) &= ~((uint32_t)ADC_INT_FLAG_EOIC);
	ENCODER_sample();
	if((UsrConfig.calib_flag == 1)&&(UsrConfig.motor_ENABLE==1))
	{
			Calibration_zero();
			ADC_Sample();
			Update_Register();
			Recive_CALC();
			Send_CALC();		
	}	
	else
	{

		// Clear EOIC
		ADC_Sample();

		Controller.input_velocity = UsrConfig.traj_vel;		
		float current_setpoint = CONTROLLER_loop(&Controller,UsrConfig.control_mode,encoder_par.vel_estimate_,encoder_par.pos_estimate_);
		float phase = encoder_par.phase_;
		FOC_current(&Foc, 0, current_setpoint, phase, phase);
	}


}

void NMI_Handler(void)
{
}

/*!
    \brief      this function handles HardFault exception
    \param[in]  none
    \param[out] none
    \retval     none
*/
void HardFault_Handler(void)
{
    /* if Hard Fault exception occurs, go to infinite loop */
    while (1);
}

/*!
    \brief      this function handles MemManage exception
    \param[in]  none
    \param[out] none
    \retval     none
*/
void MemManage_Handler(void)
{
    /* if Memory Manage exception occurs, go to infinite loop */
    while (1);
}

/*!
    \brief      this function handles BusFault exception
    \param[in]  none
    \param[out] none
    \retval     none
*/
void BusFault_Handler(void)
{
    /* if Bus Fault exception occurs, go to infinite loop */
    while (1);
}

/*!
    \brief      this function handles UsageFault exception
    \param[in]  none
    \param[out] none
    \retval     none
*/
void UsageFault_Handler(void)
{
    /* if Usage Fault exception occurs, go to infinite loop */
    while (1);
}

/*!
    \brief      this function handles SVC exception
    \param[in]  none
    \param[out] none
    \retval     none
*/
void SVC_Handler(void)
{
}

/*!
    \brief      this function handles DebugMon exception
    \param[in]  none
    \param[out] none
    \retval     none
*/
void DebugMon_Handler(void)
{
}

/*!
    \brief      this function handles PendSV exception
    \param[in]  none
    \param[out] none
    \retval     none
*/
void PendSV_Handler(void)
{
}

/*!
    \brief      this function handles SysTick exception
    \param[in]  none
    \param[out] none
    \retval     none
*/
void SysTick_Handler(void)
{
    delay_decrement();
}
