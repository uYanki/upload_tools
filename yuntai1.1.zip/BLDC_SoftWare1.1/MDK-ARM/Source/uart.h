/*
	Copyright 2021 codenocold 1107795287@qq.com
	Address : https://github.com/codenocold/dgm
	This file is part of the dgm firmware.
	The dgm firmware is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.
	The dgm firmware is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.
	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef __UART_H__
#define __UART_H__

#include "main.h"
#include "encoder.h"
#include "USER_Config.h"
#define GPIOA_ODR_Addr    			 (GPIOA+12) //0x4001100C 
#define BITBAND(addr, bitnum)    ((addr & 0xF0000000)+0x2000000+((addr &0xFFFFF)<<5)+(bitnum<<2)) 
#define MEM_ADDR(addr)  				 *((volatile unsigned long  *)(addr)) 
#define BIT_ADDR(addr, bitnum)   MEM_ADDR(BITBAND(addr, bitnum)) 
#define PAout(n)   							 BIT_ADDR(GPIOA_ODR_Addr,n)  //��� 
#define RS485_TX_EN							 PAout(1)	//485ģʽ����.0,����;1,����.
typedef struct {
				unsigned char hi;          
				unsigned char lo;         
				unsigned char Data[255];     
				unsigned short CRC_Check_Code;
				}W_CRC16;
typedef struct {
				unsigned char hi;          
				unsigned char lo;         
				unsigned char Data[255];     
				unsigned short CRC_Check_Code;
				}R_CRC16;
typedef struct 
			{ 
			//INPUT 
				unsigned char send_byte;
				unsigned char Device_address;
				unsigned char Function_code;					
				unsigned char  Get_0x10_Byte_Num;
				unsigned char  Get_0x03_Byte_Num;		
				unsigned short Get_0x10_word_Num;		
				short          send_terminus_register;
				short 				 TX_inc;
				short Device_register;
				short CRC_16_Array_label;
				short Data_0x06;
				int   Data_0x10_1;
				int   Data_0x10_2;			
			 } MODBUS_ORDER;
typedef struct _MODOBUS_USER_READ{
				// Motor
				unsigned char motor_address;		
				unsigned char motor_ENABLE;
				unsigned char control_mode;
				char 					encoder_dir;									// (Auto)
				unsigned char parameter_memory_flag;
				// Control
				short pos_kp;																// [(turn/s)/turn]λ��KP
				short vel_kp;																// [A/(turn/s)]�ٶ�KP
				short vel_ki;																// [A/((turn/s)*s)]�ٶ�KI
				short current_iq_kp;												// (Auto)����KP
				short current_iq_ki;												// (Auto)����Ki	
				unsigned short traj_accel;									// [(turn/s)/s}	
				short vel_limit;
				short input_current;			  									// [A]������λ
				short traj_vel;
				short velocity_current;											// [turn/s]��ǰ�ٶ�	ֻ��
				short inertia;
				short current_limit;
				short protect_under_voltage;
				short traj_decel;
				int 	Motor_IS;
				int 	position_current;											// ��ǰ���λ��
	
} MODOBUS_USER_READ;
void Motor_Enable(void);
void Motor_Disable(void);
void UART_init(uint32_t baudrate);
void Update_Register(void);
void Recive_CALC(void);
void Send_CALC(void);
#endif
