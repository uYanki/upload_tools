

#ifndef __PWM_CURR_FDBK_H__
#define __PWM_CURR_FDBK_H__

#include "main.h"
#include "systick.h"
#include "foc.h"

#define SHUNT_RESISTENCE	0.02f	// Resistance of phase current sampling resistor
#define V_SCALE 10.99*(3.3f / 4095.0f)     					// Bus volts per A/D Count (0.015311 V)
#define I_SCALE ((3.3f / 4095.0f) / SHUNT_RESISTENCE / 10)	// Amps per A/D Count

#define PWM_ARR					      3749 // 16KHz
#define DT						(0.0000625f)
#define TEST_2pai						(10,430.21919552736f)
#define CURRENT_MEASURE_HZ		16000

typedef struct
{
	int Ia_per_fil;
	int Ib_per_fil;	
	int adc_phase_C;
  int adc_phase_a_offset;
	int adc_phase_b_offset;
}ADC_PAR;
#define ADC_PAR_DEFAULTS {0,0,0,0,0,0,0,0,0,0,0}  // ��ʼ������

void PWMC_init(void);
void PWMC_switch_on_pwm(void);
void PWMC_switch_off_pwm(void);
void _Timer1_init(void);
void ADC_Sample(void );
void Offset_CurrentReading(void);
static void adc0_config(void);
#endif
