/*

*/
#include "systick.h"
#include "led.h"
#include "uart.h"
#include "encoder.h"
#include "pwm_curr_fdbk.h"
#include "controller.h"
#include "USER_Config.h"
#include "trapTraj.h"

tTraj 					  Traj;
ADC_PAR      			adc_par; 
R_CRC16 				  r_crc16;
W_CRC16 		 			w_crc16;
USERCONFIG 	 			UsrConfig;
MODBUS_ORDER		  modbus_order;
ControllerStruct  Controller;
MODOBUS_USER_READ modobus_user_read;
ENCODER_PAR 			encoder_par = ENCODER_PAR_DEFAULTS;

int main(void)
{
  LED_init();
 	nvic_priority_group_set(NVIC_PRIGROUP_PRE2_SUB2);
	systick_config();

	UART_init(115200);
	UsrConfig.calib_flag = STM32_FLASH_ReadHalfWord(USR_CONFIG_ROM_ADDR + 0x10);
	if(UsrConfig.calib_flag == 2)
	{
		Read_FLASH_config();				
	}
	ENCODER_init();
	_Timer1_init();

	UsrConfig.current_limit = 4;
	UsrConfig.motor_pole_pairs = 11;
	UsrConfig.vel_limit = 30;
	encoder_par.pll_ki_ = 400000;
	encoder_par.pll_kp_ = 4000;	
	Foc.v_bus = 12;
	UsrConfig.inertia = 0.1;

	PWMC_init();
	if(UsrConfig.motor_ENABLE == 1)
	{
		//Motor_Enable();	
	}
    while(1)
			{

			}
			
}

void Error_Handler(void)
{
	__disable_irq();
	PWMC_switch_off_pwm();
	
	while(1){}
}
