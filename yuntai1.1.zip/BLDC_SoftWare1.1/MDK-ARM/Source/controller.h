/*

*/

#ifndef __CONTROLLER_H__
#define __CONTROLLER_H__

#include "main.h"
#include "encoder.h"
#include "USER_Config.h"
#include "trapTraj.h"
#include "pwm_curr_fdbk.h"
#include "util.h"
typedef struct {
	float input_position;
	float input_velocity;
	float input_current;
} ControllerStruct;

extern ControllerStruct Controller;

void CONTROLLER_move_to_pos(float goal_point);

float CONTROLLER_get_integrator_current(void);
void CONTROLLER_reset(ControllerStruct *controller);
float CONTROLLER_loop(ControllerStruct *controller, int control_mode, float velocity, float position);

#endif
