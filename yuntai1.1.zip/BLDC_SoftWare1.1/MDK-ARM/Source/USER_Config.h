#ifndef USER_CONFIG
#define USER_CONFIG
#include "main.h"
#include "util.h"
#include "uart.h"
#define FMC_PAGE_SIZE        ((uint16_t)(63)*(0x400))	// 1KB
#define USR_CONFIG_ROM_ADDR					((unsigned int)(0x08000000 + FMC_PAGE_SIZE))	// Page 124
	typedef enum {
	CONTROL_MODE_CURRENT		= 0,
	CONTROL_MODE_CURRENT_RAMP	= 1,
	CONTROL_MODE_VELOCITY		= 2,
	CONTROL_MODE_VELOCITY_RAMP	= 3,
	CONTROL_MODE_POSITION		= 4,
	CONTROL_MODE_POSITION_TRAP	= 5,
} tControlMode;
typedef struct UsrConfig{
	// Motor
	int motor_ENABLE;
	int motor_address;
	int control_mode;
	int parameter_memory_flag;
	unsigned int calib_flag;
	// Encoder
	int encoder_dir;				// (Auto)
	int encoder_offset;			// (bottom layer)
	int motor_phase_resistance;	// (Auto)
	int motor_phase_inductance;	// (Auto)
	int motor_pole_pairs;			// (Auto)
	// Control
	float vel_limit;						// [turn/s]�ٶ���λ
	float traj_vel;						// [(turn/s)/s)���������ת��
	float traj_decel;						// [(turn/s)/s)���μ���
	float traj_accel;					// [(turn/s)/s}���μ��ٶ�
	float pos_kp;							// [(turn/s)/turn]λ��KP
	float vel_kp;							// [A/(turn/s)]�ٶ�KP
	float vel_ki;							// [A/((turn/s)*s)]�ٶ�KI
	float current_iq_kp;					// (Auto)����KP
	float current_iq_ki;					// (Auto)����Ki	

	float input_current;
	float current_limit;			// [A]
	float current_ramp_rate;		// [A/sec]���������ٶ�
	float vel_ramp_rate;			// [(turn/s)/s]	���������ٶ�
	float inertia;					// [A/(turn/s^2)]	ת������
	// Protect
	int protect_under_voltage;	// [V]��ѹ��������
	int offset_lut[128];	// (Auto)	
} USERCONFIG;
#define USERCONFIG_DEFAULTS {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}  // ��ʼ������

short Parameter_Save(void);
void Read_FLASH_config(void);
void Write_FLASH_config(void);
short SAVE_Config(void);
void CONFIG_Read(unsigned int ReadAddr,USERCONFIG *User_config);
unsigned int STM32_FLASH_ReadHalfWord(unsigned int faddr);






























#endif
