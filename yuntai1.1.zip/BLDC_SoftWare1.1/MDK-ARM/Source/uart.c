/*

*/

#include "uart.h"
#include "foc.h"
#include "controller.h"
extern tTraj             Traj;
extern ADC_PAR           adc_par; 
extern R_CRC16           r_crc16;
extern W_CRC16           w_crc16;
extern MODBUS_ORDER      modbus_order;
extern MODOBUS_USER_READ modobus_user_read;
extern ENCODER_PAR 			 encoder_par;
extern USERCONFIG 			 UsrConfig;

char 						UART_TX_Buffer[5];
unsigned char   receive_inc   = 0;	//���ռ���
unsigned short  TX_switch_inc = 0;	//���ͼ���
static	 short  UART_RX_count = 0;
static 	 int modobus_tmp_send = 0;	
unsigned char const CRC_hi_table[]={
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0,
    0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
    0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
    0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1,
    0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41,
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1,
    0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0,
    0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40,
    0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1,
    0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0,
    0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40,
    0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
    0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0,
    0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
    0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
    0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
    0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
    0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40,
    0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1,
    0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
    0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0,
    0x80, 0x41, 0x00, 0xC1, 0x81, 0x40};

    //CRC��λ�ֽ�ֵ��
unsigned char  const CRC_lo_table[]={
		0x00, 0xC0, 0xC1, 0x01, 0xC3, 0x03, 0x02, 0xC2, 0xC6, 0x06,
		0x07, 0xC7, 0x05, 0xC5, 0xC4, 0x04, 0xCC, 0x0C, 0x0D, 0xCD,
		0x0F, 0xCF, 0xCE, 0x0E, 0x0A, 0xCA, 0xCB, 0x0B, 0xC9, 0x09,
		0x08, 0xC8, 0xD8, 0x18, 0x19, 0xD9, 0x1B, 0xDB, 0xDA, 0x1A,
		0x1E, 0xDE, 0xDF, 0x1F, 0xDD, 0x1D, 0x1C, 0xDC, 0x14, 0xD4,
		0xD5, 0x15, 0xD7, 0x17, 0x16, 0xD6, 0xD2, 0x12, 0x13, 0xD3,
		0x11, 0xD1, 0xD0, 0x10, 0xF0, 0x30, 0x31, 0xF1, 0x33, 0xF3,
		0xF2, 0x32, 0x36, 0xF6, 0xF7, 0x37, 0xF5, 0x35, 0x34, 0xF4,
		0x3C, 0xFC, 0xFD, 0x3D, 0xFF, 0x3F, 0x3E, 0xFE, 0xFA, 0x3A,
		0x3B, 0xFB, 0x39, 0xF9, 0xF8, 0x38, 0x28, 0xE8, 0xE9, 0x29,
		0xEB, 0x2B, 0x2A, 0xEA, 0xEE, 0x2E, 0x2F, 0xEF, 0x2D, 0xED,
		0xEC, 0x2C, 0xE4, 0x24, 0x25, 0xE5, 0x27, 0xE7, 0xE6, 0x26,
		0x22, 0xE2, 0xE3, 0x23, 0xE1, 0x21, 0x20, 0xE0, 0xA0, 0x60,
		0x61, 0xA1, 0x63, 0xA3, 0xA2, 0x62, 0x66, 0xA6, 0xA7, 0x67,
		0xA5, 0x65, 0x64, 0xA4, 0x6C, 0xAC, 0xAD, 0x6D, 0xAF, 0x6F,
		0x6E, 0xAE, 0xAA, 0x6A, 0x6B, 0xAB, 0x69, 0xA9, 0xA8, 0x68,
		0x78, 0xB8, 0xB9, 0x79, 0xBB, 0x7B, 0x7A, 0xBA, 0xBE, 0x7E,
		0x7F, 0xBF, 0x7D, 0xBD, 0xBC, 0x7C, 0xB4, 0x74, 0x75, 0xB5,
		0x77, 0xB7, 0xB6, 0x76, 0x72, 0xB2, 0xB3, 0x73, 0xB1, 0x71,
		0x70, 0xB0, 0x50, 0x90, 0x91, 0x51, 0x93, 0x53, 0x52, 0x92,
		0x96, 0x56, 0x57, 0x97, 0x55, 0x95, 0x94, 0x54, 0x9C, 0x5C,
		0x5D, 0x9D, 0x5F, 0x9F, 0x9E, 0x5E, 0x5A, 0x9A, 0x9B, 0x5B,
		0x99, 0x59, 0x58, 0x98, 0x88, 0x48, 0x49, 0x89, 0x4B, 0x8B,
		0x8A, 0x4A, 0x4E, 0x8E, 0x8F, 0x4F, 0x8D, 0x4D, 0x4C, 0x8C,
		0x44, 0x84, 0x85, 0x45, 0x87, 0x47, 0x46, 0x86, 0x82, 0x42,
		0x43, 0x83, 0x41, 0x81, 0x80, 0x40};
void W_CRC16_calc(W_CRC16 *p,char crc_index_)//W_CRC16_cal
{

	unsigned char Array_label = 0;
	p->lo=0xff;
	p->hi=0xff;	
	for(char _index=0;_index < crc_index_;_index++)
			{

				unsigned char tmp_8 = p->lo^p->Data[Array_label];
				p->lo=p->hi^(CRC_hi_table[tmp_8]);
				p->hi=CRC_lo_table[tmp_8];
				if((_index == 2)&&(modbus_order.Function_code == 3))
				{
					Array_label = modbus_order.CRC_16_Array_label;
				}else{Array_label++;}
			}

	return;
}
void R_CRC16_calc(R_CRC16 *p,short crc_index_)//R_CRC16_cal
{

	p->lo=0xff;
	p->hi=0xff;
	for(char _index=0;_index<crc_index_;_index++)
			{
				unsigned char tmp_8=p->lo^p->Data[_index];
				p->lo=p->hi^(CRC_hi_table[tmp_8]);
				p->hi=CRC_lo_table[tmp_8];
				
			}
	return;
}

void DMA_Enable_TX(uint8_t len)
{
	//while(RESET == usart_flag_get(USART1, USART_FLAG_TBE));
		 usart_data_transmit(USART1,UART_TX_Buffer[0]);
	
	 while(RESET == usart_flag_get(USART1, USART_FLAG_TC));
}
void UART_init(uint32_t baudrate)
{
	rcu_periph_clock_enable(RCU_AF);
	rcu_periph_clock_enable(RCU_GPIOA);
	usart_deinit(USART1);
  rcu_periph_clock_enable(RCU_USART1);
//	rcu_periph_clock_enable(RCU_DMA0);
	/* connect port to USARTx_Tx */
	gpio_init(GPIOA, GPIO_MODE_AF_PP, GPIO_OSPEED_50MHZ, GPIO_PIN_2);

	/* connect port to USARTx_Rx */
	gpio_init(GPIOA, GPIO_MODE_IPD, GPIO_OSPEED_50MHZ, GPIO_PIN_3);

	/* USART configure */

	usart_word_length_set(USART1, USART_WL_8BIT);
	usart_stop_bit_set(USART1, USART_STB_1BIT);
	usart_baudrate_set(USART1, baudrate);
	usart_parity_config(USART1, USART_PM_NONE);
	usart_hardware_flow_rts_config(USART1, USART_RTS_DISABLE);
	usart_hardware_flow_cts_config(USART1, USART_CTS_DISABLE);
	usart_receive_config(USART1, USART_RECEIVE_ENABLE);
	usart_transmit_config(USART1, USART_TRANSMIT_ENABLE);
	usart_enable(USART1);

	rcu_periph_clock_enable(RCU_GPIOA);
	gpio_init(GPIOA, GPIO_MODE_OUT_PP, GPIO_OSPEED_50MHZ, GPIO_PIN_1);

	delay_1ms(10);
	UART_RX_count=0;
	delay_1ms(1);
	RS485_TX_EN=0;
}
void Update_Register(void)
{
	modobus_user_read.motor_address										= UsrConfig.motor_address;
	modobus_user_read.motor_ENABLE 				 					  = UsrConfig.motor_ENABLE;		
	modobus_user_read.control_mode 										= UsrConfig.control_mode;
	modobus_user_read.encoder_dir 	 									= UsrConfig.encoder_dir ;
	modobus_user_read.parameter_memory_flag 	 				= UsrConfig.parameter_memory_flag;						
	modobus_user_read.pos_kp 													= UsrConfig.pos_kp*100;	
	modobus_user_read.inertia													=	(UsrConfig.inertia*100);
	modobus_user_read.current_limit										= UsrConfig.current_limit*100;	
	modobus_user_read.vel_kp 													= UsrConfig.vel_kp*100;	
	modobus_user_read.vel_ki 	 												= UsrConfig.vel_ki*100;		
	modobus_user_read.current_iq_kp 									= UsrConfig.current_iq_kp*100;								
	modobus_user_read.current_iq_ki 									= UsrConfig.current_iq_ki*100;	
	modobus_user_read.traj_decel											= UsrConfig.traj_decel*100;	
	modobus_user_read.traj_accel 											= UsrConfig.traj_accel*100;	
	modobus_user_read.traj_vel												= UsrConfig.traj_vel*60.0;	
	modobus_user_read.input_current										= UsrConfig.input_current*100;
	modobus_user_read.protect_under_voltage						= UsrConfig.protect_under_voltage;	
	

	


	modobus_user_read.velocity_current 				  			= encoder_par.vel_estimate_*60.0;		
	modobus_user_read.position_current 				  			= encoder_par.pos_estimate_*32767;		

}
void Motor_Enable(void)
{

	timer_channel_output_state_config(TIMER0, TIMER_CH_0, TIMER_CCX_ENABLE);
	timer_channel_output_state_config(TIMER0, TIMER_CH_1, TIMER_CCX_ENABLE);
	timer_channel_output_state_config(TIMER0, TIMER_CH_2, TIMER_CCX_ENABLE);
	timer_channel_complementary_output_state_config(TIMER0, TIMER_CH_0, TIMER_CCXN_ENABLE);
	timer_channel_complementary_output_state_config(TIMER0, TIMER_CH_1, TIMER_CCXN_ENABLE);
	timer_channel_complementary_output_state_config(TIMER0, TIMER_CH_2, TIMER_CCXN_ENABLE);
}
void Motor_Disable(void)
{

	timer_channel_output_state_config(TIMER0, TIMER_CH_0, TIMER_CCX_DISABLE);
	timer_channel_output_state_config(TIMER0, TIMER_CH_1, TIMER_CCX_DISABLE);
	timer_channel_output_state_config(TIMER0, TIMER_CH_2, TIMER_CCX_DISABLE);
	timer_channel_complementary_output_state_config(TIMER0, TIMER_CH_0, TIMER_CCXN_DISABLE);
	timer_channel_complementary_output_state_config(TIMER0, TIMER_CH_1, TIMER_CCXN_DISABLE);
	timer_channel_complementary_output_state_config(TIMER0, TIMER_CH_2, TIMER_CCXN_DISABLE);
}

void Recive_CALC()
{
	
	if((USART1_FLAG_->SR)&(0x20))//���յ�����
	{	 		
		UART_RX_count = 0;
		char res = usart_data_receive(USART1);
			switch (receive_inc)
		{
			case 0:
				r_crc16.Data[0]=res;
				receive_inc++;
				break;
			case 1:
				r_crc16.Data[1]=res;
				receive_inc++;
				break;
			case 2:
				r_crc16.Data[2]=res;
				receive_inc++;
				break;
			case 3:
				r_crc16.Data[3]=res;
				receive_inc++;
				break;	
			case 4:
				r_crc16.Data[4]=res;
				receive_inc++;
				break;
			case 5:
				r_crc16.Data[5]=res;
				receive_inc++;
				break;
			case 6://CRC��λ;
				r_crc16.hi=0xff;
				r_crc16.lo=0xff; 
				R_CRC16_calc(&r_crc16,6);
				r_crc16.Data[6]=res;
				receive_inc++;
			break;
			case 7:
				r_crc16.Data[7]=res;
				if((r_crc16.Data[6]==r_crc16.lo)&&(r_crc16.Data[7]==r_crc16.hi))//Check CRC put in MODbus Struct;
					{
						UART_RX_count=0;
						modbus_order.Device_address   = r_crc16.Data[0];
						if(modbus_order.Device_address!=modobus_user_read.motor_address)
						{
							if(modbus_order.Device_address == 0)//Broadcast address
							{
								;
							}else
							{
								return;
							}
						}
						modbus_order.Function_code    = r_crc16.Data[1];
						modbus_order.Device_register  = r_crc16.Data[2]<<8;
						modbus_order.Device_register |= r_crc16.Data[3];	
						modbus_order.Data_0x06   		  = r_crc16.Data[4]<<8;
						modbus_order.Data_0x06  	   |= r_crc16.Data[5];	
						if(modbus_order.Function_code==0x06)
								{
									switch(modbus_order.Device_register)
									{
										case 00://motor_address
											UsrConfig.motor_address = modbus_order.Data_0x06;																					
										break;
										case 01://motor_ENABLE
											if(UsrConfig.motor_ENABLE == 2)
											{
												gpio_bit_set(GPIOB,GPIO_PIN_3);
											}
											UsrConfig.motor_ENABLE  = abs(modbus_order.Data_0x06);
											if(UsrConfig.motor_ENABLE == 1)
												{
													gpio_bit_reset(GPIOB,GPIO_PIN_3);
													Motor_Enable();	
													return;
												}else if(UsrConfig.motor_ENABLE == 0)
												{
													Motor_Disable();	
													return;
												}		
											break;
										case 02://control_mode
												Motor_Disable();
												UsrConfig.control_mode = modbus_order.Data_0x06;
												Motor_Enable();
											break;
										case 03://encoder_par.encode_DIR
											UsrConfig.encoder_dir = modbus_order.Data_0x06;	
											break;			
										case 04://user_config.parameter_memory_flag
											UsrConfig.parameter_memory_flag = modbus_order.Data_0x06;		
											if(UsrConfig.parameter_memory_flag == 1)
												{
													Motor_Disable();
													UsrConfig.parameter_memory_flag = Parameter_Save();
												}	
											break;														
										case 5://UsrConfig.pos_kp
											UsrConfig.pos_kp = ((float)modbus_order.Data_0x06/100.0f);											
											break;			
										case 6://UsrConfig.inertia
											UsrConfig.inertia = ((float)modbus_order.Data_0x06/100.0f);
											break;			
										case 7://UsrConfig.current_limit
											UsrConfig.current_limit = ((float)modbus_order.Data_0x06/100.0f);
											break;			
										case 8://vel_kp
											UsrConfig.vel_kp = ((float)modbus_order.Data_0x06/100.0f);
											break;			
										case 9://vel_ki
											UsrConfig.vel_ki = ((float)modbus_order.Data_0x06/100.0f);
											break;			
										case 10://current_iq_kp
											UsrConfig.current_iq_kp = ((float)modbus_order.Data_0x06/100.0f);			
											break;		
										case 11://current_iq_ki
											UsrConfig.current_iq_ki = ((float)modbus_order.Data_0x06/100.0f);
											break;	
										case 12://UsrConfig.vel_limit
											UsrConfig.vel_limit = ((float)modbus_order.Data_0x06/100.0f);
											break;		
										case 13://UsrConfig.traj_decel
											UsrConfig.traj_decel = ((float)modbus_order.Data_0x06/100.0f);
											break;
										case 14://UsrConfig.traj_accel
											UsrConfig.traj_accel = ((float)modbus_order.Data_0x06/100.0f);
											break;
										case 15://UsrConfig.traj_vel
											UsrConfig.traj_vel = (modbus_order.Data_0x06/60.0f);
											break;							
										case 16://UsrConfig.input_current
												UsrConfig.input_current	= ((float)modbus_order.Data_0x06/100.0f);	
												Controller.input_current = UsrConfig.input_current;
											break;
										case 17:
												UsrConfig.protect_under_voltage = modbus_order.Data_0x06;
										break;
										case 18:
											break;
										case 20://position_Target_H
											break;
										case 21://position_Target_L
											break;
										case 22://	

										
											break;										
										case 530://Calibration zero
											if(modbus_order.Data_0x06 == 1)
												{
													UsrConfig.calib_flag = 1;
													encoder_par.mCalibStep = 0;
												}
											break;
									 }
										UART_RX_count=0;
										receive_inc=0;												
										RS485_TX_EN=1;
								}	else if(modbus_order.Function_code==0x03)
												{
													//��������Ҫ�ļĴ����յ�λ�úͳ�ʼλ��
													modbus_order.Get_0x03_Byte_Num = modbus_order.Data_0x06<<1;
													if((modbus_order.Device_register == 1)||(modbus_order.Device_register == 2)||(modbus_order.Device_register == 3)||(modbus_order.Device_register == 4))
														{
															if((modbus_order.Device_register == 1)||(modbus_order.Device_register == 2))
															{
																modbus_order.TX_inc = 3;
																modbus_order.send_terminus_register = 4 + modbus_order.Data_0x06;
																modbus_order.CRC_16_Array_label = 3;
															}else
															{
																modbus_order.send_terminus_register = 5 + modbus_order.Data_0x06;
																modbus_order.TX_inc = 5;
																modbus_order.CRC_16_Array_label = 5;
															}		
														}else
														{										
															modbus_order.TX_inc = (modbus_order.Device_register<<1) - 3;
															modbus_order.send_terminus_register = modbus_order.Device_register + modbus_order.Data_0x06 + 1;//�յ�Ĵ�������
															modbus_order.CRC_16_Array_label = (modbus_order.Device_register<<1) - 3;//��ʼ�Ĵ�����CRC����λ��
														}																											
													modbus_order.send_byte = (modbus_order.Get_0x03_Byte_Num) + 3;	//CRC��Ҫ���ֽ���
													receive_inc=0;
													RS485_TX_EN=1;
												}
					}else if(r_crc16.Data[1]==0x10)
							{
								receive_inc++;
								return;
							}else{
								UART_RX_count=0;
								receive_inc=0;	}
				break;
				case 8:
						r_crc16.Data[8] = res;
						receive_inc++;
					break;
				case 9:
						r_crc16.Data[9] = res;
						receive_inc++;					
					break;
				case 10:
						r_crc16.Data[10] = res;
						receive_inc++;					
					break;
				case 11:
						r_crc16.hi = 0xff;
						r_crc16.lo = 0xff; 
						R_CRC16_calc(&r_crc16,11);
						r_crc16.Data[11] = res;
						receive_inc++;					
					break;
				case 12:
						r_crc16.Data[12] = res;
						receive_inc = 0;	
						if((r_crc16.Data[11]==r_crc16.lo)&&(r_crc16.Data[12]==r_crc16.hi))
							{
									int tmp_float,position;
									modbus_order.Device_address				= r_crc16.Data[0];
									modbus_order.Function_code				= r_crc16.Data[1];
									modbus_order.Device_register 			= r_crc16.Data[2]<<8;								//���ֽ���ǰ
									modbus_order.Device_register		 |= r_crc16.Data[3];									//���ֽ��ں�
									if(modbus_order.Device_register == 0x13)
									{
										modbus_order.Get_0x10_word_Num    = r_crc16.Data[4]<<8;
										modbus_order.Get_0x10_word_Num   |= r_crc16.Data[5];	
										modbus_order.Get_0x10_Byte_Num    = r_crc16.Data[6];
										modbus_order.Data_0x10_1    		  = r_crc16.Data[7]<<8;	
										modbus_order.Data_0x10_1         |= r_crc16.Data[8];	
										modbus_order.Data_0x10_2          = r_crc16.Data[9]<<8;	
										modbus_order.Data_0x10_2         |= r_crc16.Data[10];		
										
										position   = modbus_order.Data_0x10_1<<16;//���ֽ���ǰ
										position  |= modbus_order.Data_0x10_2;		//���ֽ��ں�
										position  *= UsrConfig.encoder_dir;
										Controller.input_position = (float)position/(float)32767;
										CONTROLLER_move_to_pos(Controller.input_position);
										if(UsrConfig.motor_ENABLE==1)
										{

										}
									}
									else{return;}
									r_crc16.Data[7] = 0;
									r_crc16.Data[8] = 0;
									r_crc16.Data[9] = 0;
									r_crc16.Data[10] = 0;
									RS485_TX_EN=1;		
							}else{	UART_RX_count=0;
											receive_inc=0;}							
							
					break;
		}
			return;
	}else
		{
			UART_RX_count++;
			if(UART_RX_count==200)
			{
				
				UART_RX_count=0;
				receive_inc=0;
			}

		}
			


}

void Send_CALC(void)
{

	if(RS485_TX_EN == 1)
	{
		TX_switch_inc++;
		if(modbus_order.Function_code == 0x03)
			{
				switch(TX_switch_inc)
				{
					case 1:
								w_crc16.Data[0]= modobus_user_read.motor_address;
								UART_TX_Buffer[0]=w_crc16.Data[0];
								DMA_Enable_TX(1);	
					break;
					case 2:
								w_crc16.Data[1]= 03;
								UART_TX_Buffer[0]=w_crc16.Data[1];
								DMA_Enable_TX(1);	
					break;		
					case 3:
								w_crc16.Data[2]= modbus_order.Get_0x03_Byte_Num;
								UART_TX_Buffer[0]=w_crc16.Data[2];
								TX_switch_inc = modbus_order.TX_inc;
								DMA_Enable_TX(1);						
					break;							
					case 4:
								w_crc16.Data[3]= modobus_user_read.motor_ENABLE;
								UART_TX_Buffer[0]=w_crc16.Data[3];
								DMA_Enable_TX(1);	
					break;
					case 5:
								w_crc16.Data[4]= modobus_user_read.control_mode;
								UART_TX_Buffer[0]=w_crc16.Data[4];
								DMA_Enable_TX(1);	
								if(modbus_order.send_terminus_register == 3)
								{
									TX_switch_inc = 47;
								}				
					break;
					case 6:
								w_crc16.Data[5]= modobus_user_read.encoder_dir;
								UART_TX_Buffer[0]=w_crc16.Data[5];
								DMA_Enable_TX(1);	
					break;
					case 7:
								w_crc16.Data[6]= modobus_user_read.parameter_memory_flag;
								UART_TX_Buffer[0]=w_crc16.Data[6];
								DMA_Enable_TX(1);	
								if(modbus_order.send_terminus_register == 6)
								{
									TX_switch_inc = 47;
								}					
					break;
					case 8:
								w_crc16.Data[7] = modobus_user_read.pos_kp>>8;	
								UART_TX_Buffer[0]=w_crc16.Data[7];
								DMA_Enable_TX(1);	
					break;
					case 9:		
								w_crc16.Data[8] = modobus_user_read.pos_kp;	
								UART_TX_Buffer[0]=w_crc16.Data[8];
								DMA_Enable_TX(1);
								if(modbus_order.send_terminus_register == 7)
								{
									TX_switch_inc = 47;
								}									
					break;
					case 10:
								w_crc16.Data[9]= modobus_user_read.inertia>>8;	
								UART_TX_Buffer[0]=w_crc16.Data[9];
								DMA_Enable_TX(1);	
					break;
					case 11:
								w_crc16.Data[10]= modobus_user_read.inertia;
								UART_TX_Buffer[0]=w_crc16.Data[10];
								DMA_Enable_TX(1);	
								if(modbus_order.send_terminus_register == 8)
								{
									TX_switch_inc = 47;
								}										
					
					break;
					case 12:
								w_crc16.Data[11]= modobus_user_read.current_limit>>8;
								UART_TX_Buffer[0]=w_crc16.Data[11];
								DMA_Enable_TX(1);	
					break;
					case 13:			
								w_crc16.Data[12]= modobus_user_read.current_limit;	
								UART_TX_Buffer[0]=w_crc16.Data[12];		
								DMA_Enable_TX(1);		
								if(modbus_order.send_terminus_register == 9)
								{
									TX_switch_inc = 47;
								}							
					break;
					case 14:
								w_crc16.Data[13]= modobus_user_read.vel_kp>>8;
								UART_TX_Buffer[0]=w_crc16.Data[13];
								DMA_Enable_TX(1);	
					break;
					case 15:		
								w_crc16.Data[14]= modobus_user_read.vel_kp;		
								UART_TX_Buffer[0]=w_crc16.Data[14];
								DMA_Enable_TX(1);	
								if(modbus_order.send_terminus_register == 10)
								{
									TX_switch_inc = 47;
								}									
					break;
					case 16:
								w_crc16.Data[15]= modobus_user_read.vel_ki>>8;
								UART_TX_Buffer[0]=w_crc16.Data[15];
								DMA_Enable_TX(1);	
					break;
					case 17:
								w_crc16.Data[16]= modobus_user_read.vel_ki;
								UART_TX_Buffer[0]=w_crc16.Data[16];
								DMA_Enable_TX(1);
								if(modbus_order.send_terminus_register == 11)
								{
									TX_switch_inc = 47;
								}						
					break;
					case 18:
								w_crc16.Data[17]= modobus_user_read.current_iq_kp>>8;
								UART_TX_Buffer[0]=w_crc16.Data[17];
								DMA_Enable_TX(1);	
					break;
					case 19:
								w_crc16.Data[18]= modobus_user_read.current_iq_kp;
								UART_TX_Buffer[0]=w_crc16.Data[18];
								DMA_Enable_TX(1);	
								if(modbus_order.send_terminus_register == 12)
								{
									TX_switch_inc = 47;
								}					
					break;
					case 20:
								w_crc16.Data[19]= modobus_user_read.current_iq_ki>>8;
								UART_TX_Buffer[0]=w_crc16.Data[19];
								DMA_Enable_TX(1);	
					break;
					case 21:
								w_crc16.Data[20] = modobus_user_read.current_iq_ki;		
					      UART_TX_Buffer[0]= w_crc16.Data[20];
								DMA_Enable_TX(1);
								if(modbus_order.send_terminus_register == 13)
								{
									TX_switch_inc = 47;
								}			
					break;
					case 22:
								modobus_tmp_send = modobus_user_read.vel_limit;
								w_crc16.Data[21] = modobus_tmp_send>>8;
								UART_TX_Buffer[0]= w_crc16.Data[21];
								DMA_Enable_TX(1);	
					break;
					case 23:
								w_crc16.Data[22] = modobus_tmp_send;	
								UART_TX_Buffer[0]= w_crc16.Data[22];
								DMA_Enable_TX(1);	
								if(modbus_order.send_terminus_register == 14)
								{
									TX_switch_inc = 47;
								}							
					break;
					case 24:
								w_crc16.Data[23]= modobus_user_read.traj_decel>>8;
								UART_TX_Buffer[0]=w_crc16.Data[23];
								DMA_Enable_TX(1);	
					break;
					case 25:
								w_crc16.Data[24]= modobus_user_read.traj_decel;
								UART_TX_Buffer[0]=w_crc16.Data[24];
								DMA_Enable_TX(1);
								if(modbus_order.send_terminus_register == 15)
								{
									TX_switch_inc = 47;
								}					
					break;
					case 26:								
								w_crc16.Data[25]= modobus_user_read.traj_accel>>8;
								UART_TX_Buffer[0]=w_crc16.Data[25];
								DMA_Enable_TX(1);	
					break;
					case 27:
								w_crc16.Data[26]= modobus_user_read.traj_accel;
								UART_TX_Buffer[0]=w_crc16.Data[26];
								DMA_Enable_TX(1);	
								if(modbus_order.send_terminus_register == 16)
								{
									TX_switch_inc = 47;
								}							
					break;
					case 28:
								modobus_tmp_send = (modobus_user_read.traj_vel);
								w_crc16.Data[27] = modobus_tmp_send>>8;
								UART_TX_Buffer[0]=w_crc16.Data[27];
								DMA_Enable_TX(1);	
					break;
					case 29:
								w_crc16.Data[28]= modobus_tmp_send;		
								UART_TX_Buffer[0]=w_crc16.Data[28];
								DMA_Enable_TX(1);
								if(modbus_order.send_terminus_register == 17)
								{
									TX_switch_inc = 47;
								}			
					break;
					case 30:
								modobus_tmp_send = modobus_user_read.input_current;
								w_crc16.Data[29]= modobus_tmp_send>>8;
								UART_TX_Buffer[0]=w_crc16.Data[29];
								DMA_Enable_TX(1);	
					break;
					case 31:
								w_crc16.Data[30]= modobus_tmp_send;			
								UART_TX_Buffer[0]=w_crc16.Data[30];
								DMA_Enable_TX(1);	
								if(modbus_order.send_terminus_register == 18)
								{
									TX_switch_inc = 47;
								}					
					break;
					case 32:								
								modobus_tmp_send = modobus_user_read.protect_under_voltage;
								w_crc16.Data[31]=	modobus_tmp_send>>8;				
								UART_TX_Buffer[0]=w_crc16.Data[31];
								DMA_Enable_TX(1);	
					break;
					case 33:
								w_crc16.Data[32]=	modobus_tmp_send;
								UART_TX_Buffer[0]=w_crc16.Data[32];
								DMA_Enable_TX(1);	
								if(modbus_order.send_terminus_register == 19)
								{
									TX_switch_inc = 47;
								}				
					break;
					case 34:
								modobus_tmp_send = Foc.i_a*100;								
								w_crc16.Data[33]= modobus_tmp_send>>8;							
								UART_TX_Buffer[0]=w_crc16.Data[33];
								DMA_Enable_TX(1);	
					break;
					case 35:
								w_crc16.Data[34]= modobus_tmp_send;								
								UART_TX_Buffer[0]=w_crc16.Data[34];
								DMA_Enable_TX(1);
								if(modbus_order.send_terminus_register == 20)
								{
									TX_switch_inc = 47;
								}			
					break;
					case 36:
								modobus_tmp_send = Foc.i_b*100;
								w_crc16.Data[35] = modobus_tmp_send>>8;
								UART_TX_Buffer[0]=w_crc16.Data[35];
								DMA_Enable_TX(1);	
					break;
					case 37:
								w_crc16.Data[36]= modobus_tmp_send;			
								UART_TX_Buffer[0]=w_crc16.Data[36];
								DMA_Enable_TX(1);			
								if(modbus_order.send_terminus_register == 21)
								{
									TX_switch_inc = 47;
								}				
					break;
					case 38:
								modobus_tmp_send = (modobus_user_read.velocity_current);										
								w_crc16.Data[37] = modobus_tmp_send>>8;
								UART_TX_Buffer[0]=w_crc16.Data[37];
								DMA_Enable_TX(1);	
					break;
					case 39:
								w_crc16.Data[38]= modobus_tmp_send;			
								UART_TX_Buffer[0]=w_crc16.Data[38];
								DMA_Enable_TX(1);			
								if(modbus_order.send_terminus_register == 22)
								{
									TX_switch_inc = 47;
								}				
					break;								
					case 40:
								modobus_tmp_send = modobus_user_read.position_current;
								w_crc16.Data[39] = modobus_tmp_send>>24;
								UART_TX_Buffer[0]=w_crc16.Data[39];
								DMA_Enable_TX(1);	
					break;
					case 41:
								w_crc16.Data[40] = modobus_tmp_send>>16;
								UART_TX_Buffer[0]=w_crc16.Data[40];
								DMA_Enable_TX(1);
								if(modbus_order.send_terminus_register == 23)
								{
									TX_switch_inc = 47;
								}				
					break;
					case 42:
								w_crc16.Data[41] = modobus_tmp_send>>8;
								UART_TX_Buffer[0]=w_crc16.Data[41];
								DMA_Enable_TX(1);	
					break;
					case 43:
								w_crc16.Data[42] = modobus_tmp_send;			
								UART_TX_Buffer[0]=w_crc16.Data[42];
								DMA_Enable_TX(1);						
								if(modbus_order.send_terminus_register == 24)
								{
									TX_switch_inc = 47;
								}							
					break;			
					case 44:						
								modobus_tmp_send =	Foc.v_bus;										//��Դ��ѹ
								w_crc16.Data[43] = modobus_tmp_send>>24;
								UART_TX_Buffer[0]=w_crc16.Data[43];
								DMA_Enable_TX(1);	
					break;
					case 45:
								w_crc16.Data[44] = modobus_tmp_send>>16;
								UART_TX_Buffer[0]=w_crc16.Data[44];
								DMA_Enable_TX(1);
								if(modbus_order.send_terminus_register == 25)
								{
									TX_switch_inc = 47;
								}				
					break;
					case 46:
								w_crc16.Data[45] = modobus_tmp_send>>8;
								UART_TX_Buffer[0]=w_crc16.Data[45];
								DMA_Enable_TX(1);	
					break;
					case 47:
								w_crc16.Data[46] = modobus_tmp_send;			
								UART_TX_Buffer[0]=w_crc16.Data[46];
								DMA_Enable_TX(1);						
					break;						
					case 48:
								W_CRC16_calc(&w_crc16,modbus_order.send_byte);
								w_crc16.Data[47]=w_crc16.lo;
								UART_TX_Buffer[0]=w_crc16.Data[47];
								DMA_Enable_TX(1);	
					break;
					case 49:
								w_crc16.Data[48]=w_crc16.hi;
								UART_TX_Buffer[0]=w_crc16.Data[48];
								DMA_Enable_TX(1);
								TX_switch_inc=0;
								RS485_TX_EN=0;
								modbus_order.Function_code=0;
					break;
					}
				return;
			}else if((modbus_order.Function_code==0x06)||(modbus_order.Function_code==0x010))
							{
								switch(TX_switch_inc)
								{
									case 1:
												w_crc16.Data[0]= modobus_user_read.motor_address;
												UART_TX_Buffer[0]=w_crc16.Data[0];
												DMA_Enable_TX(1);	
									break;
									case 2:
												w_crc16.Data[1]= modbus_order.Function_code;
												UART_TX_Buffer[0]=w_crc16.Data[1];
												DMA_Enable_TX(1);	
									break;
									case 3:
												w_crc16.Data[2]= modbus_order.Device_register>>8;
												UART_TX_Buffer[0]=w_crc16.Data[2];
												DMA_Enable_TX(1);						
									break;					
									case 4:
												w_crc16.Data[3]= modbus_order.Device_register;
												UART_TX_Buffer[0]=w_crc16.Data[3];
												DMA_Enable_TX(1);	
									break;
									case 5:	
												if(modbus_order.Function_code==0x06)
												{w_crc16.Data[4]= modbus_order.Data_0x06>>8;}
												else{w_crc16.Data[4] = modbus_order.Get_0x10_word_Num>>8;}
												UART_TX_Buffer[0]=w_crc16.Data[4];
												DMA_Enable_TX(1);	
									break;
									case 6:
												if(modbus_order.Function_code==0x06)
												{w_crc16.Data[5]= modbus_order.Data_0x06;}
												else{w_crc16.Data[5] = modbus_order.Get_0x10_word_Num;}								
												UART_TX_Buffer[0]=w_crc16.Data[5];
												DMA_Enable_TX(1);	
									break;
									case 7:
												W_CRC16_calc(&w_crc16,6);
												w_crc16.Data[6]=w_crc16.lo;
												UART_TX_Buffer[0]=w_crc16.Data[6];
												DMA_Enable_TX(1);	
								 break;
									case 8:
												w_crc16.Data[7]=w_crc16.hi;
												UART_TX_Buffer[0]=w_crc16.Data[7];
												DMA_Enable_TX(1);
												TX_switch_inc=0;
												RS485_TX_EN=0;
												modbus_order.Function_code=0;
								 break;								
								}
								return;
							}
	}
	
	
}

