#include "USER_Config.h"

extern  tTraj       Traj;
extern  USERCONFIG 	UsrConfig;
extern  ENCODER_PAR encoder_par;
extern	MODOBUS_USER_READ modobus_user_read;
short SAVE_Config(void)
{     
	uint32_t* pData = (uint32_t*)&UsrConfig;
	fmc_state_enum status;
  fmc_unlock();
	ob_unlock();
	// Erase
  fmc_flag_clear(FMC_FLAG_END|FMC_FLAG_WPERR|FMC_FLAG_PGERR);
	status = fmc_page_erase(USR_CONFIG_ROM_ADDR);
	fmc_flag_clear(FMC_FLAG_END|FMC_FLAG_WPERR|FMC_FLAG_PGERR);
	
	if(status == FMC_READY)
		{
		// Program
		for(int i=0; i<sizeof(USERCONFIG)/4; i++)
				{
				status = fmc_word_program(USR_CONFIG_ROM_ADDR+i*4,*(pData+i));
				fmc_flag_clear(FMC_FLAG_END|FMC_FLAG_WPERR|FMC_FLAG_PGERR);
				if(status != FMC_READY)
					{
						break;
					}
				}
		}
	
	fmc_lock();
	return (status != FMC_READY);

}
unsigned int STM32_FLASH_ReadHalfWord(unsigned int faddr)
{
	return *(unsigned int*)faddr; 
} 
void CONFIG_Read(unsigned int ReadAddr,USERCONFIG *UsrConfig)   	
{
	int *P_User_config = &UsrConfig->motor_ENABLE;
	for(unsigned int i=0;i<sizeof(USERCONFIG)/4;i++)
	{
		*P_User_config=STM32_FLASH_ReadHalfWord(ReadAddr);
		ReadAddr+=4;
		P_User_config++;
	}
}
void Read_FLASH_config()
{

	CONFIG_Read(USR_CONFIG_ROM_ADDR,&UsrConfig);
	encoder_par.pll_ki_ = 400000;
	encoder_par.pll_kp_ = 400;	
}
void Write_FLASH_config()
{
	UsrConfig.motor_ENABLE 				 					  = 1;		
	UsrConfig.control_mode 										= 4;//user_config.control_mode;
	UsrConfig.encoder_dir 	 									= 1;//user_config.encoder_dir;
	UsrConfig.traj_accel 											= 40;	
	UsrConfig.traj_decel 											= 40;	
	UsrConfig.vel_limit 	 										= 30.0;	
	UsrConfig.current_limit										= 4;	
	UsrConfig.protect_under_voltage 				  = 0;			
	UsrConfig.current_iq_kp 									= 3.0;
	UsrConfig.current_iq_ki 									= 1.0;	
	UsrConfig.vel_kp    											= 1.0;
	UsrConfig.vel_ki													= 5.0;	
	UsrConfig.pos_kp 													= 80.0;	
	UsrConfig.traj_vel												= 15;
	UsrConfig.input_current										= 1;
	UsrConfig.motor_pole_pairs 								= 12;
	UsrConfig.vel_limit = 30;
	SAVE_Config();

}
short Parameter_Save(void)
{
	SAVE_Config();
	return 2;
}
